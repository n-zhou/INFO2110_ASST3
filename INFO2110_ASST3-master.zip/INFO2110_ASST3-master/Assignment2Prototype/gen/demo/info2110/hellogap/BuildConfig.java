/** Automatically generated file. DO NOT MODIFY */
package demo.info2110.hellogap;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}